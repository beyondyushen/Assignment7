package erchashu;


	public class Node {
		 private int id; 
		 Node lchild;
	     Node rchild;
		 Node pa=null;
		 Node root =null;
		 Node(){
			 this.lchild = null;this.rchild = null;this.pa=null;}

			Node(int name,Node left,Node right,Node p){
				this.id =name;
				this.lchild = left;
				this.rchild = right;
				this.pa = p;
			}
			
		
		
			
			Node(int id2) {
				this.id = id2;
			}

			public Node getPa() {
				return pa;
			}

			public void setPa(Node pa) {
				this.pa = pa;
			}

			public void setLchild(Node lchild) {
				this.lchild = lchild;
			}

			public void setRchild(Node rchild) {
				this.rchild = rchild;
			}

			public int getId() {
				return id;
			}

			public void setId(int id) {
				this.id = id;
			}

			public Node getLchild() {
				return lchild;
			}

			public void setLchild(int k,Node lchild) {
				this.lchild = lchild;
				this.id = k;
			}
		
			public Node getRchild() {
				return rchild;
			}

			public void setRchild(int k,Node rchild) {
				this.rchild = rchild;
				this.id = k;
			}
		 
		 
		 
	}

