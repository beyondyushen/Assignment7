package erchashu;

import javax.swing.JTree;





//http://www.linuxidc.com/Linux/2015-04/116275.htm 
public class bitTree implements IAVLTree{
	Node parrent = null;
	private static Node root;
	bitTree(){this.root=null;};

	bitTree(int id,Node a,Node b,Node c){
	new Node(id,a,b,c);
		
	}



	@Override
	public Node get(int id) {
		Node node = new Node(id);
		 System.out.println("��Ҫ���ҵ��ǣ�"+id);
		
	
		 
		 
		 
		
	            if(root==null){
	                System.out.println("����Ϊ������");
	                return null;
	            }
	            
	            
	            
	                               //��ʼ����
	                boolean isFound=false;   
	                Node x=root;
	                Node y=null;
	                while(!isFound&&x!=null){    //���鵽���ߵ���Ҷ�ӽڵ㻹û�鵽ʱ���սᣡ
	                    y=x;
	                    if(node.getId()==x.getId()){   
	                        isFound=true;
	                    }else{                    //ͨ���Ƚϴ�С���������
	                        if(node.getId()>x.getId()){   
	                            x=x.rchild;
	                        }else{
	                            x=x.lchild;
	                        }
	                    }
	                }
	                
	                if(isFound){    //�����ҵ��� 
	                	
		         	            System.out.println("����"+node.getId()+"�ɹ���");
		         	     
		                	return y;
	                
	                	
	                }
	               
         	         
	                
	                
	                System.out.println("����û�иý�㣡");
         	     
                	
	            
		
		
		//û���ҵ�
		return null;
	}

	@Override
	public void insert(int id, Node newNode) {
		Node parent = null;
		newNode = new Node(id,null,null,null);
		Node r = root;
		
		if(root == null){root = newNode;return;}
		while(r!=null){
				parent=r;
				if(id<r.getId()){r = r.lchild;}
				else if(id>r.getId()){r = r.rchild;}
				else return;}//Ѱ�Ҳ���λ�ã���
	
		//�ҵ�֮��
		if(id<parent.getId()){parent.lchild = newNode;newNode.pa=parent;}
		if(id>parent.getId()){parent.rchild = newNode;newNode.pa=parent;}
		
		
		
		
		
		return ;
		
	}

	@Override
	public void delete(int id) {
		//��get���  ����Ҫ�ҵ��ڵ�
		Node node1 = get(id);
		if( node1!=null){
				//��ʱ˵������
		//��ʱ��ʼɾ�����ɡ�
			Node node= get(id);
			boolean  can =(node==null);
			if(can){
					System.out.println("����ɾ���սڵ�");
				}
			
			repla(node);
			System.out.println("��ɾ��");
		}else{
			//û�ҵ�
			System.out.println("�޴˽ڵ�");
		}
		
		
		}
	public void repla(Node node){
		//�жϺ���ӵ�����
		boolean ch = (node.lchild!=null&&node.rchild!=null);
		if(ch){replace(node);}
		else{
			if(node.lchild!=null){node=node.lchild;}
			else if(node.rchild!=null){node=node.rchild;}
			else{ if(node==node.pa.lchild){
	            node.pa.lchild=null;
	        }else{
	            node.pa.rchild=null;
	        }}
		}
		
	}
	public void replace(Node node){
		Node Y= this.getp(node);
		node.setId(Y.getId());
		repla(Y);
	}
	private Node getMinNode(Node node){    
        if(node!=null){
            Node x=node;
            Node y=null;
            boolean k = x!=null;
            while(k){    
                y=x;
                x=x.lchild;
                k = x!=null;
            }
            return y;
        }
        return null;
    }
		

	public Node getp(Node node){
			if(node.rchild!=null){
					return getMinNode(node.rchild); 
				
			}
			else{ Node x=node;
            Node y=node.pa;
            while(y!=null&&x==y.rchild){
                x=y;
                y=y.pa;
            }return y;}
		
	}//��ú�̽ڵ�

	@Override
	public JTree printTree() {
		
		
		return null;
	}
	static void midOrderTraverse() {
		 System.out.println("���������");
	        midOrderTraverse(root);
	        System.out.println();
	    }
	    private static void midOrderTraverse(Node node){    //�������
	        if(node!=null){
	            midOrderTraverse(node.lchild);
	            System.out.print("-"+node.getId()+"-");
	            midOrderTraverse(node.rchild);
	        }
	    }}
